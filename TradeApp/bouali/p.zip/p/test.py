def hello(to='yasser'):
    print('hello ', to)


hello()
name = input('what is your name ')
hello(name)
